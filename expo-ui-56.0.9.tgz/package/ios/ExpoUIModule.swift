// Copyright 2025-present 650 Industries. All rights reserved.

import ExpoModulesCore
import SwiftUI

public final class ExpoUIModule: Module {
  public func definition() -> ModuleDefinition {
    Name("ExpoUI")

    View(RNHostView.self)

    OnDestroy {
      Task { @MainActor in
        NamespaceRegistry.shared.removeAll()
      }
    }

    // MARK: - Observable State

    makeWorkletCallbackClass()

    Class(ObservableState.self) {
      Constructor { (initial: [String: Any]) -> ObservableState in
        return ObservableState(value: initial["value"])
      }

      Function("getValue") { (state: ObservableState) -> Any in
        return state.value ?? NSNull()
      }

      Function("setValue") { (state: ObservableState, wrapper: [String: Any]) in
        let newValue = wrapper["value"]
        // Update state on the UI thread
        if Thread.isMainThread {
          state.value = newValue
        } else {
          DispatchQueue.main.async {
            state.value = newValue
          }
        }
      }

      Function("setOnChange") { (state: ObservableState, callback: WorkletCallback?) in
        state.onChange = callback
      }
    }

    // MARK: - Module Functions

    AsyncFunction("completeRefresh") { (id: String) in
      RefreshableManager.shared.completeRefresh(id: id)
    }

    AsyncFunction("withAnimation") { (
      animation: AnimationConfig?,
      body: WorkletCallback,
      completion: WorkletCallback?,
      completionCriteria: AnimationCompletionCriteriaType?
    ) in
      let swiftUIAnimation = animation?.toSwiftUIAnimation()

      if let completion {
        if #available(iOS 17.0, tvOS 17.0, *) {
          let criteria: SwiftUI.AnimationCompletionCriteria =
            completionCriteria == .removed ? .removed : .logicallyComplete
          withAnimation(swiftUIAnimation, completionCriteria: criteria) {
            body.invoke()
          } completion: {
            completion.invoke()
          }
          return
        }
      }

      withAnimation(swiftUIAnimation) {
        body.invoke()
      }
    }
    .runOnQueue(.main)

    // MARK: - Expo UI Views with AsyncFunctions

    ExpoUIView(SecureFieldView.self) {
      AsyncFunction("setText") { (view: SecureFieldView, text: String) in
        view.setText(text)
      }
      AsyncFunction("clear") { (view: SecureFieldView) in
        view.clear()
      }
      AsyncFunction("blur") { (view: SecureFieldView) in
        view.blur()
      }
      AsyncFunction("focus") { (view: SecureFieldView) in
        view.focus()
      }
    }
    ExpoUIView(TextFieldView.self) {
      AsyncFunction("setText") { (view: TextFieldView, text: String) in
        view.setText(text)
      }
      AsyncFunction("clear") { (view: TextFieldView) in
        view.clear()
      }
      AsyncFunction("blur") { (view: TextFieldView) in
        view.blur()
      }
      AsyncFunction("focus") { (view: TextFieldView) in
        view.focus()
      }
      AsyncFunction("setSelection") { (view: TextFieldView, start: Int, end: Int) in
        view.setSelection(start: start, end: end)
      }
    }
    ExpoUIView(ShareLinkView.self) {
      AsyncFunction("setItem") { (view: ShareLinkView, url: String?) in
        guard let url, let validURL = URL(string: url) else {
          view.rejectContinuation()
          return
        }
        view.resolveContinuation(validURL)
      }
    }

    // MARK: - Views that apply common view modifiers internally

    View(HostView.self)
    View(TextView.self)

    // MARK: - Views that don't support common view modifiers

    View(SlotView.self)
    View(NamespaceView.self)
    View(GridRowView.self)

    // MARK: - Expo UI Views

    ExpoUIView(AlertView.self)
    ExpoUIView(BottomSheetView.self)
    ExpoUIView(ExpoUI.Button.self)
    ExpoUIView(ChartView.self)
    ExpoUIView(ColorPickerView.self)
    ExpoUIView(DatePickerView.self)
    ExpoUIView(DisclosureGroupView.self)
    ExpoUIView(ExpoUI.ContentUnavailableView.self)
    ExpoUIView(ConfirmationDialogView.self)
    ExpoUIView(ExpoUI.ContextMenu.self)

    ExpoUIView(ControlGroupView.self)

    ExpoUIView(MenuView.self)

    ExpoUIView(FormView.self)
    ExpoUIView(GaugeView.self)
    ExpoUIView(GroupView.self)
    ExpoUIView(HStackView.self)
    ExpoUIView(LazyHStackView.self)
    ExpoUIView(LazyVStackView.self)
    ExpoUIView(ImageView.self)
    ExpoUIView(LabelView.self)
    ExpoUIView(ListView.self)
    ExpoUIView(ListForEachView.self)

    ExpoUIView(PickerView.self)

    ExpoUIView(ExpoUI.ProgressView.self)
    ExpoUIView(SectionView.self)

    ExpoUIView(SliderView.self)

    ExpoUIView(SpacerView.self)
    ExpoUIView(StepperView.self)
    ExpoUIView(ToggleView.self)
    ExpoUIView(VStackView.self)
    ExpoUIView(ZStackView.self)
    ExpoUIView(GlassEffectContainerView.self)
    ExpoUIView(LabeledContentView.self)
    ExpoUIView(ScrollViewComponent.self)
    ExpoUIView(SwipeActionsView.self)
    ExpoUIView(RectangleView.self)
    ExpoUIView(RoundedRectangleView.self)
    ExpoUIView(EllipseView.self)
    ExpoUIView(UnevenRoundedRectangleView.self)
    ExpoUIView(CapsuleView.self)
    ExpoUIView(CircleView.self)
    ExpoUIView(ConcentricRectangleView.self)
    ExpoUIView(DividerView.self)
    ExpoUIView(PopoverView.self)
    ExpoUIView(OverlayView.self)
    ExpoUIView(MaskView.self)
    ExpoUIView(GridView.self)
    ExpoUIView(AccessoryWidgetBackgroundView.self)
    ExpoUIView(LinkView.self)
    ExpoUIView(TabView.self)
    ExpoUIView(Tab.self)

    // Experimental SwiftUI state support to trigger synchronous state updates from UI worklet.
    ExpoUIView(SyncToggleView.self)
  }
}
