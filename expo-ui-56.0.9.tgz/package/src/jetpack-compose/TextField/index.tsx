import { requireNativeView } from 'expo';
import type { Ref } from 'react';
import type { ColorValue } from 'react-native';

import { worklets } from '../../State/optionalWorklets';
import type { ObservableState } from '../../State/useNativeState';
import { useWorkletProp } from '../../State/useWorkletProp';
import { getStateId } from '../../State/utils';
import type { ModifierConfig, ViewEvent } from '../../types';
import { Slot } from '../SlotView';
import { createViewModifierEventListener } from '../modifiers/utils';

// region Types

/**
 * Can be used for imperatively focusing and setting text/selection on the `TextField` component.
 */
export type TextFieldRef = {
  setText: (newText: string) => Promise<void>;
  /** Clear the current text. */
  clear: () => Promise<void>;
  focus: () => Promise<void>;
  blur: () => Promise<void>;
  /**
   * Programmatically set the selection range.
   */
  setSelection: (start: number, end: number) => Promise<void>;
};

export type TextFieldCapitalization = 'none' | 'characters' | 'words' | 'sentences';

export type TextFieldKeyboardType =
  | 'text'
  | 'number'
  | 'email'
  | 'phone'
  | 'decimal'
  | 'password'
  | 'ascii'
  | 'uri'
  | 'numberPassword';

export type TextFieldImeAction =
  | 'default'
  | 'none'
  | 'go'
  | 'search'
  | 'send'
  | 'previous'
  | 'next'
  | 'done';

/**
 * Keyboard options matching Compose `KeyboardOptions`.
 */
export type TextFieldKeyboardOptions = {
  /** @default 'none' */
  capitalization?: TextFieldCapitalization;
  /** @default true */
  autoCorrectEnabled?: boolean;
  /** @default 'text' */
  keyboardType?: TextFieldKeyboardType;
  /** @default 'default' */
  imeAction?: TextFieldImeAction;
};

/**
 * Keyboard actions matching Compose `KeyboardActions`.
 * The triggered callback depends on the `imeAction` in `keyboardOptions`.
 */
export type TextFieldKeyboardActions = {
  onDone?: (value: string) => void;
  onGo?: (value: string) => void;
  onNext?: (value: string) => void;
  onPrevious?: (value: string) => void;
  onSearch?: (value: string) => void;
  onSend?: (value: string) => void;
};

/**
 * Colors for `TextField` and `OutlinedTextField`.
 * Maps to `TextFieldColors` in Compose, shared by both variants.
 */
export type TextFieldColors = {
  focusedTextColor?: ColorValue;
  unfocusedTextColor?: ColorValue;
  disabledTextColor?: ColorValue;
  errorTextColor?: ColorValue;
  focusedContainerColor?: ColorValue;
  unfocusedContainerColor?: ColorValue;
  disabledContainerColor?: ColorValue;
  errorContainerColor?: ColorValue;
  cursorColor?: ColorValue;
  errorCursorColor?: ColorValue;
  focusedIndicatorColor?: ColorValue;
  unfocusedIndicatorColor?: ColorValue;
  disabledIndicatorColor?: ColorValue;
  errorIndicatorColor?: ColorValue;
  focusedLeadingIconColor?: ColorValue;
  unfocusedLeadingIconColor?: ColorValue;
  disabledLeadingIconColor?: ColorValue;
  errorLeadingIconColor?: ColorValue;
  focusedTrailingIconColor?: ColorValue;
  unfocusedTrailingIconColor?: ColorValue;
  disabledTrailingIconColor?: ColorValue;
  errorTrailingIconColor?: ColorValue;
  focusedLabelColor?: ColorValue;
  unfocusedLabelColor?: ColorValue;
  disabledLabelColor?: ColorValue;
  errorLabelColor?: ColorValue;
  focusedPlaceholderColor?: ColorValue;
  unfocusedPlaceholderColor?: ColorValue;
  disabledPlaceholderColor?: ColorValue;
  errorPlaceholderColor?: ColorValue;
  focusedSupportingTextColor?: ColorValue;
  unfocusedSupportingTextColor?: ColorValue;
  disabledSupportingTextColor?: ColorValue;
  errorSupportingTextColor?: ColorValue;
  focusedPrefixColor?: ColorValue;
  unfocusedPrefixColor?: ColorValue;
  disabledPrefixColor?: ColorValue;
  errorPrefixColor?: ColorValue;
  focusedSuffixColor?: ColorValue;
  unfocusedSuffixColor?: ColorValue;
  disabledSuffixColor?: ColorValue;
  errorSuffixColor?: ColorValue;
};

/** Shared props between `TextField` and `OutlinedTextField`. */
type BaseTextFieldProps = {
  ref?: Ref<TextFieldRef>;
  /**
   * An observable state that holds the current text value. Create one with
   * `useNativeState('initial text')`. If omitted, the field manages its own
   * internal state.
   */
  value?: ObservableState<string>;
  /** If true, the text field will be focused automatically when mounted. @default false */
  autoFocus?: boolean;
  /** @default true */
  enabled?: boolean;
  /** @default false */
  readOnly?: boolean;
  /** @default false */
  isError?: boolean;
  /** @default false */
  singleLine?: boolean;
  maxLines?: number;
  minLines?: number;
  /**
   * Display-time text transformation. `'password'` masks every character;
   * `'none'` (default) leaves the buffer as-is.
   */
  visualTransformation?: 'password' | 'none';

  /**
   * Selection-related colors. Maps to Compose's `TextSelectionColors` via
   * `LocalTextSelectionColors`. `handleColor` controls the drag handles;
   * `backgroundColor` is the highlighted-text background (typically the same
   * tint at lower alpha so the underlying text stays readable).
   */
  textSelectionColors?: {
    handleColor?: ColorValue;
    backgroundColor?: ColorValue;
  };

  /**
   * Observable state holding the current selection range. Create with
   * `useNativeState({ start: 0, end: 0 })`. The field writes user-driven
   * changes back to it, and writes from JS (or a worklet) update the
   * cursor/selection in the field. Use `ref.setSelection(start, end)` for
   * imperative one-shot updates.
   */
  selection?: ObservableState<{ start: number; end: number }>;

  /** Maximum number of characters allowed. Truncates natively as the user types. */
  maxLength?: number;

  /** Called when the selection range changes. */
  onSelectionChange?: (selection: { start: number; end: number }) => void;

  /**
   * Text styling for the field's content. Maps to Compose's `TextStyle`.
   */
  textStyle?: {
    textAlign?: 'left' | 'right' | 'center' | 'justify';
    color?: ColorValue;
    fontSize?: number;
    fontFamily?: string;
    fontWeight?:
      | '100'
      | '200'
      | '300'
      | '400'
      | '500'
      | '600'
      | '700'
      | '800'
      | '900'
      | 'normal'
      | 'bold';
    lineHeight?: number;
    letterSpacing?: number;
  };
  keyboardOptions?: TextFieldKeyboardOptions;
  keyboardActions?: TextFieldKeyboardActions;
  /**
   * Fires whenever the text value changes. If marked with the `'worklet'`
   * directive, runs synchronously on the UI thread; otherwise delivered
   * asynchronously as a regular JS event. Use `onSelectionChange` (or read
   * the `selection` observable) to react to selection-only changes.
   */
  onValueChange?: (value: string) => void;
  /** A callback triggered when the field gains or loses focus. */
  onFocusChanged?: (focused: boolean) => void;
  shape?: object;
  modifiers?: ModifierConfig[];
  /** Slot children (e.g. `TextField.Label`, `TextField.Placeholder`). */
  children?: React.ReactNode;
};

export type TextFieldProps = BaseTextFieldProps & {
  colors?: TextFieldColors;
};

export type OutlinedTextFieldProps = BaseTextFieldProps & {
  colors?: TextFieldColors;
};

// endregion Types

// region Native

type NativeTextFieldProps = Omit<
  BaseTextFieldProps,
  | 'value'
  | 'selection'
  | 'onValueChange'
  | 'onFocusChanged'
  | 'onSelectionChange'
  | 'keyboardActions'
  | 'children'
  | 'shape'
> & {
  variant: 'filled' | 'outlined';
  colors?: TextFieldColors;
  shape?: object;
  children?: React.ReactNode;
  value?: number | null;
  selection?: number | null;
  onValueChangeSync?: number | null;
} & ViewEvent<'onValueChange', { text: string; selection: { start: number; end: number } }> &
  ViewEvent<'onFocusChanged', { value: boolean }> &
  ViewEvent<'onSelectionChange', { start: number; end: number }> &
  ViewEvent<'onKeyboardAction', { action: string; value: string }>;

const TextFieldNativeView: React.ComponentType<NativeTextFieldProps> = requireNativeView(
  'ExpoUI',
  'TextFieldView'
);

function useTransformedProps(
  props: TextFieldProps | OutlinedTextFieldProps,
  variant: 'filled' | 'outlined'
): NativeTextFieldProps {
  const {
    value,
    selection,
    modifiers,
    children,
    keyboardActions,
    onValueChange,
    onFocusChanged,
    onSelectionChange,
    ...restProps
  } = props;

  const isWorklet = !!onValueChange && !!worklets?.isWorkletFunction?.(onValueChange);
  const workletCallback = useWorkletProp(isWorklet ? onValueChange : undefined, 'onValueChange');

  return {
    modifiers,
    ...(modifiers ? createViewModifierEventListener(modifiers) : undefined),
    ...restProps,
    variant,
    children,
    value: getStateId(value),
    selection: getStateId(selection),
    onValueChangeSync: getStateId(workletCallback),
    onValueChange:
      !isWorklet && onValueChange ? (event) => onValueChange(event.nativeEvent.text) : undefined,
    onFocusChanged: onFocusChanged ? (event) => onFocusChanged(event.nativeEvent.value) : undefined,
    onSelectionChange: onSelectionChange
      ? (event) => onSelectionChange({ start: event.nativeEvent.start, end: event.nativeEvent.end })
      : undefined,
    onKeyboardAction: keyboardActions
      ? (event) => {
          const { action, value } = event.nativeEvent;
          const actionMap: Record<string, ((v: string) => void) | undefined> = {
            done: keyboardActions.onDone,
            go: keyboardActions.onGo,
            next: keyboardActions.onNext,
            previous: keyboardActions.onPrevious,
            search: keyboardActions.onSearch,
            send: keyboardActions.onSend,
          };
          actionMap[action]?.(value);
        }
      : undefined,
  };
}

// endregion Native

// region Slot components

function Label(props: { children: React.ReactNode }) {
  return <Slot slotName="label">{props.children}</Slot>;
}

function Placeholder(props: { children: React.ReactNode }) {
  return <Slot slotName="placeholder">{props.children}</Slot>;
}

function LeadingIcon(props: { children: React.ReactNode }) {
  return <Slot slotName="leadingIcon">{props.children}</Slot>;
}

function TrailingIcon(props: { children: React.ReactNode }) {
  return <Slot slotName="trailingIcon">{props.children}</Slot>;
}

function Prefix(props: { children: React.ReactNode }) {
  return <Slot slotName="prefix">{props.children}</Slot>;
}

function Suffix(props: { children: React.ReactNode }) {
  return <Slot slotName="suffix">{props.children}</Slot>;
}

function SupportingText(props: { children: React.ReactNode }) {
  return <Slot slotName="supportingText">{props.children}</Slot>;
}

// endregion Slot components

// region Components

/**
 * A Material3 `TextField`.
 */
function TextFieldComponent(props: TextFieldProps) {
  return <TextFieldNativeView {...useTransformedProps(props, 'filled')} />;
}

TextFieldComponent.Label = Label;
TextFieldComponent.Placeholder = Placeholder;
TextFieldComponent.LeadingIcon = LeadingIcon;
TextFieldComponent.TrailingIcon = TrailingIcon;
TextFieldComponent.Prefix = Prefix;
TextFieldComponent.Suffix = Suffix;
TextFieldComponent.SupportingText = SupportingText;

/**
 * A Material3 `OutlinedTextField` with a transparent background and border outline.
 */
function OutlinedTextFieldComponent(props: OutlinedTextFieldProps) {
  return <TextFieldNativeView {...useTransformedProps(props, 'outlined')} />;
}

OutlinedTextFieldComponent.Label = Label;
OutlinedTextFieldComponent.Placeholder = Placeholder;
OutlinedTextFieldComponent.LeadingIcon = LeadingIcon;
OutlinedTextFieldComponent.TrailingIcon = TrailingIcon;
OutlinedTextFieldComponent.Prefix = Prefix;
OutlinedTextFieldComponent.Suffix = Suffix;
OutlinedTextFieldComponent.SupportingText = SupportingText;

// endregion Components

export { TextFieldComponent as TextField, OutlinedTextFieldComponent as OutlinedTextField };

// Exported for docs api data
export { type ObservableState };
