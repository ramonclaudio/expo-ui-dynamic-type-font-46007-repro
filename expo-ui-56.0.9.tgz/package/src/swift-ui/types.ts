/**
 * The alignment of content within a container or overlay.
 * Maps to SwiftUI's `Alignment` type.
 */
export type Alignment =
  | 'center'
  | 'leading'
  | 'trailing'
  | 'top'
  | 'bottom'
  | 'topLeading'
  | 'topTrailing'
  | 'bottomLeading'
  | 'bottomTrailing'
  | 'centerFirstTextBaseline'
  | 'centerLastTextBaseline'
  | 'leadingFirstTextBaseline'
  | 'leadingLastTextBaseline'
  | 'trailingFirstTextBaseline'
  | 'trailingLastTextBaseline';

/**
 * Common frame properties that can be applied to any view.
 */
export interface FrameProps {
  /**
   * The width of the frame.
   */
  width?: number;
  /**
   * The height of the frame.
   */
  height?: number;

  /**
   * The minimum width of the frame.
   */
  minWidth?: number;
  /**
   * The ideal width of the frame.
   */
  idealWidth?: number;
  /**
   * The maximum width of the frame.
   */
  maxWidth?: number;
  /**
   * The minimum height of the frame.
   */
  minHeight?: number;
  /**
   * The ideal height of the frame.
   */
  idealHeight?: number;
  /**
   * The maximum height of the frame.
   */
  maxHeight?: number;

  /**
   * The alignment of the content within the frame.
   */
  alignment?: Alignment;
}

/**
 * Common padding properties that can be applied to any view.
 */
export interface PaddingProps {
  /**
   * The padding on the top.
   */
  top?: number;
  /**
   * The padding on the leading edge (left in LTR, right in RTL).
   */
  leading?: number;
  /**
   * The padding on the bottom.
   */
  bottom?: number;
  /**
   * The padding on the trailing edge (right in LTR, left in RTL).
   */
  trailing?: number;
}

/**
 * A closed date range with lower and upper bounds.
 */
export type ClosedRangeDate = { lower: Date; upper: Date };

/**
 * Common props that can be applied to any view.
 */
export interface CommonViewModifierProps {
  /**
   * Used to locate this view in end-to-end tests.
   */
  testID?: string;

  /**
   * Array of view modifiers to apply to this view.
   * Modifiers are applied in the order they appear in the array.
   *
   * @example
   * ```tsx
   * import { background, cornerRadius, shadow, frame, padding, fixedSize } from '@expo/ui/swift-ui/modifiers';
   *
   * <Text modifiers={[
   *   background('#FF0000'),
   *   cornerRadius(10),
   *   padding({ all: 16 }),
   *   frame({ width: 200 }),
   *   shadow({ radius: 5, x: 0, y: 2 })
   * ]}>
   *   Hello World
   * </Text>
   * ```
   */
  modifiers?: import('./modifiers').ViewModifier[];
}
